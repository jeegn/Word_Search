public class Puzzle {
    /***
     *constructor: fn is the filename
     *where the puzzle is stored
     ***/
    public Puzzle(String fn) {
	//TO BE IMPLEMENTED
    }

    /***
     *search the puzzle for the given word
     *return {a, b, x, y} where (a, b) is
     *the starting location and (x, y) is 
     *the ending location
     *return null if the word can't be found
     *in the puzzle
     ***/
    public int[] search(String word) {
	//TO BE IMPLEMENTED
    }
}